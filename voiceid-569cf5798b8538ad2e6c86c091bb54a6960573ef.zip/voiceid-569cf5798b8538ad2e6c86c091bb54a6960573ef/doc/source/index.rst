.. Voiceid documentation master file, created by
   sphinx-quickstart on Fri Feb 24 12:06:51 2012.


Voiceid's documentation
===================================


.. toctree::
   :maxdepth: 2
   
   abstract
   intro
   architecture
   database
   tests
   application
   conclusion
   basics
   api



Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

